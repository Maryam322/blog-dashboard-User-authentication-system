from django.urls import path
from . import views

app_name = 'blog'

urlpatterns = [
    path('', views.BlogListView.as_view(), name='blog_list'),
    path('create/', views.BlogCreateView.as_view(), name='blog_create'),
    path('user/<int:pk>/', views.UserProfileView.as_view(), name='user_profile'),
    path('<slug:slug>/', views.BlogDetailView.as_view(), name='blog_detail'),
    path('<slug:slug>/edit/', views.BlogUpdateView.as_view(), name='blog_update'),
    path('<slug:slug>/delete/', views.BlogDeleteView.as_view(), name='blog_delete'),
]
